//SessionEvents.js (executed before subsite - onStart)

session.siteLayout = {};
session.siteLayout.gutterTop = 20; //Extra space top of AreaPane ViewContainer
session.siteLayout.gutterSide = 20; //Extra space left,right of AreaPane ViewContainer
session.siteLayout.SystemName = "";
//session.siteLayout.isSmallScreen = undefined;
session.siteLayout.isTouchScreen = undefined;
session.siteLayout.screenSizeLevel = undefined; //undefined=not set, 0=normal/big, 1=small, 2=very small
session.siteLayout.menuOpen = false;
session.siteLayout.menuSymbolElement = undefined;
session.siteLayout.areaMenuIndex = 0;
session.siteLayout.siteView;

session.siteLayout.initSiteView = function (siteView) {
	session.siteLayout.siteView = siteView;
}

session.siteLayout.getScreenSizeLevel = function (refresh) {
	if (session.siteLayout.screenSizeLevel === undefined || refresh) {
		var sWidth = session.width();
		var sLimit1 = session.theme.themeSizes.NormalListWidth.size() * 4;
		var sLimit2 = session.theme.themeSizes.LargeListWidth.size();	 //256 or 256*1.5

		if (sWidth <= sLimit2) {
			session.siteLayout.screenSizeLevel = 2;
		}
		else if (sWidth < sLimit1) {
			session.siteLayout.screenSizeLevel = 1;
		}
		else {
			session.siteLayout.screenSizeLevel = 0;
		}
		//console.log("session.siteLayout.screenSizeLevel: "+session.siteLayout.screenSizeLevel+", sWidth: "+sWidth)
	}
	return session.siteLayout.screenSizeLevel;
}
session.siteLayout.getIsTouchScreen = function (refresh) {
	if (session.siteLayout.isTouchScreen === undefined || refresh) {
		session.siteLayout.isTouchScreen = session.densityFactor() > 1;
	}
	return session.siteLayout.isTouchScreen;
}
session.siteLayout.hideMainMenu = function (menuElement) {
	//debugger;
	var mainMenuW = session.siteLayout.mainMenuWidth();
	session.siteLayout.siteView.MainMenuPane.left(-400);
	session.siteLayout.menuOpen = false;

	session.siteLayout.updateScreenLayout();
	var newL = session.siteLayout.areaPaneLeft();
	session.siteLayout.siteView.AreaPane.left(newL);

	if (menuElement && session.siteLayout.menuSymbolElement === undefined) {
		session.siteLayout.menuSymbolElement = menuElement;
	}
	if (session.siteLayout.menuSymbolElement) {
		session.siteLayout.menuSymbolElement.value(0);
	}
	return true;
}

session.siteLayout.showMainMenu = function (menuElement) {
	//debugger;		
	session.siteLayout.siteView.MainMenuPane.left(0);
	session.siteLayout.menuOpen = true;

	session.siteLayout.updateScreenLayout();
	var newL = session.siteLayout.areaPaneLeft();
	session.siteLayout.siteView.AreaPane.left(newL);

	if (menuElement && session.siteLayout.menuSymbolElement === undefined) {
		session.siteLayout.menuSymbolElement = menuElement;
	}
	if (session.siteLayout.menuSymbolElement) {
		session.siteLayout.menuSymbolElement.value(1);
	}
	return true;
}
session.siteLayout.areaPaneLeft = function () {
	//console.log("areaPaneLeft()");
	if (session.siteLayout.getScreenSizeLevel() >= 1) {
		return session.siteLayout.gutterSide;
	}
	else if (session.siteLayout.menuOpen) {
		var l = session.siteLayout.siteView.MainMenuPane.left() + session.siteLayout.siteView.MainMenuPane.width() + session.siteLayout.gutterSide;
		return l;
	}
	else {
		return session.siteLayout.gutterSide;
	}
}
session.siteLayout.areaPaneTop = function () {
	return session.theme.fontSizes.MediumList.height() + session.siteLayout.gutterTop;
}

session.siteLayout.areaPaneWidth = function () {
	//console.log("areaPaneWidth()");
	return session.width() - session.siteLayout.siteView.AreaPane.left() - session.siteLayout.gutterSide;
}
session.siteLayout.areaPaneHeight = function () {
	return session.height() - session.theme.fontSizes.MediumList.height() - session.siteLayout.gutterTop;
}

session.siteLayout.topLeftWidth = function () { //{return this.session.theme.themeSizes.LargeListWidth.size();}
	console.log("topLeftWidth()");
	if (session.siteLayout.getScreenSizeLevel() >= 1) {
		return session.theme.fontSizes.MediumList.iconSize() + 2 * session.theme.themeSizes.NormalListPadding.size();
	}
	return session.theme.themeSizes.LargeListWidth.size();

}
session.siteLayout.topCenterWidth = function () {
	return session.width() - session.theme.themeSizes.LargeListWidth.size() - session.siteLayout.topRightWidth();
}
session.siteLayout.topRightWidth = function () {
	//console.log("topRightWidth()");
	// //if(session.siteLayout.menuSymbolElement && session.siteLayout.menuSymbolElement.visible())
	// {//logged in
	// if(session.siteLayout.getIsSmallScreen())
	// {
	// return session.theme.themeSizes.MediumListWidth.size();
	// }
	// }
	return session.theme.themeSizes.LargeListWidth.size() + 25;


}
session.siteLayout.loginVCLeft = function () {
	// if(session.siteLayout.getIsSmallScreen())
	// {

	// }
	return session.width() / 2 - 150;

}
session.siteLayout.mainMenuWidth = function () { //{return this.session.theme.themeSizes.LargeListWidth.size();}    

	if (session.siteLayout.getScreenSizeLevel() === 2) {
		return session.theme.themeSizes.MediumListWidth.size();
	}
	return session.theme.themeSizes.LargeListWidth.size();

}
session.siteLayout.updateMenuLayout = function () {

	//console.log("updateMenuLayout()");
	if (session.siteLayout.siteView) {
		//debugger;
		var sWidth = session.width();
		var isLoggedIn = session.user.accessValue > 0;
		var topRightWidth = 0;
		var topLeftWidth = 0;

		if (session.siteLayout.getScreenSizeLevel() >= 1) {

			session.siteLayout.siteView.TopCenter.top(-100);
			//debugger;
			if (isLoggedIn) {
				session.siteLayout.siteView.TopLeft.currentView.LogoSymbol.visible(false);
				topLeftWidth = session.theme.fontSizes.MediumList.iconSize() + 2 * session.theme.themeSizes.NormalListPadding.size();

				if (session.siteLayout.getIsTouchScreen()) {
					//topRightWidth = session.theme.themeSizes.NormalListWidth.size();
					topRightWidth = session.theme.themeSizes.MediumListWidth.size();
				}
				else {
					topRightWidth = session.siteLayout.topRightWidth();
				}

			}
			else {
				topLeftWidth = session.theme.themeSizes.NormalListWidth.size();
				//topRightWidth = session.theme.themeSizes.MediumListWidth.size();
				if (session.siteLayout.getIsTouchScreen()) {
					topRightWidth = session.theme.themeSizes.NormalListWidth.size();
				}
				else {
					topRightWidth = session.siteLayout.topRightWidth();
				}
			}




			session.siteLayout.siteView.TopLeft.width(topLeftWidth);
			session.siteLayout.siteView.TopRight.width(topRightWidth)
			session.siteLayout.siteView.TopRight.left(sWidth - topRightWidth);
			//session.siteLayout.siteView.TopCenter.left(topLeftWidth);
			//session.siteLayout.siteView.TopCenter.width(sWidth - topLeftWidth - topRightWidth);
			session.siteLayout.siteView.TopCenterLarge.left(topLeftWidth);


		}
		else {

			//session.siteLayout.siteView.TopCenter.visible(true);	
			//session.siteLayout.siteView.TopCenter.currentView.CenterLable.visible(true);	
			//session.siteLayout.updateCenterLableVisibility();
			session.siteLayout.siteView.TopCenter.top(0);
			session.siteLayout.siteView.TopLeft.currentView.LogoSymbol.visible(true);

			topLeftWidth = session.theme.themeSizes.LargeListWidth.size();
			topRightWidth = session.siteLayout.topRightWidth();

			session.siteLayout.siteView.TopLeft.width(topLeftWidth);
			session.siteLayout.siteView.TopRight.width(topRightWidth);
			session.siteLayout.siteView.TopRight.left(sWidth - topRightWidth);
			session.siteLayout.siteView.TopCenter.left(topLeftWidth);
			session.siteLayout.siteView.TopCenter.width(sWidth - topLeftWidth - topRightWidth);
			session.siteLayout.siteView.TopCenterLarge.left(topLeftWidth);



		}
	}
}
session.siteLayout.updateScreenLayout = function () {
	//debugger;	
	var oldVal = session.siteLayout.screenSizeLevel;
	session.siteLayout.getScreenSizeLevel(true);
	session.siteLayout.getIsTouchScreen(true);
	if (session.siteLayout.screenSizeLevel >= 1) {
		session.siteLayout.gutterSide = 0;
		session.siteLayout.gutterTop = 0;
	}
	else {
		session.siteLayout.gutterSide = 20;
		session.siteLayout.gutterTop = 20;
	}
	if (oldVal !== session.siteLayout.screenSizeLevel && session.siteLayout.siteView) {
		session.siteLayout.siteView.AreaPane.left(session.siteLayout.areaPaneLeft());
	}
	session.siteLayout.updateMenuLayout();
}
session.resizeListener = function (resizeObj) {
	//	debugger;
	if (resizeObj && resizeObj.width) {
		//var sWidth = resizeObj.width;
		session.siteLayout.updateScreenLayout();
	}
}
session.siteLayout.updateCenterLableVisibility = function () {
	//debugger;
	if (session.siteLayout.siteView.TopCenter) {
		if (session.siteLayout.getScreenSizeLevel() >= 1) {
			//session.siteLayout.siteView.TopCenter.visible(false);
			session.siteLayout.siteView.TopCenter.top(-100);
		}
		else {
			//session.siteLayout.siteView.TopCenter.visible(true);
			session.siteLayout.siteView.TopCenter.top(0);
		}
	}
}
session.siteLayout.openDashMenus = function (openFrom) {

	//var siteView = openFrom.parent.parent;
	var siteView = session.siteLayout.siteView;
	//siteView.TopCenter.visible(true);
	siteView.TopCenter.top(0);
	siteView.TopCenter.openView(
		{
			file: 'sitelayout/topcenterdash.cwlv.json',
			name: 'TopCenterDash',
			openedFrom: openFrom
		}, {});
	siteView.TopCenterLarge.visible(false);
	siteView.TopRight.visible(true);
	siteView.TopRight.openView(
		{
			file: 'sitelayout/toprightmenu.cwlv.json',
			name: 'TopRightMenu',
			openedFrom: openFrom
		}, {});
	if (siteView.TopRight.currentView !== undefined) {
		siteView.TopRight.currentView.Dashboard.visible(true);
		siteView.TopRight.currentView.AlarmOverview.visible(true);
	}

	//var isLoggedIn = session.user.accessValue>0;
	if (session.siteLayout.getScreenSizeLevel() >= 1) {
		//Close menu for smallScreens...
		session.siteLayout.hideMainMenu();
	}


	return true;
}
session.siteLayout.openAreaMenus = function (openFrom, area) {
	//var siteView = openFrom.parent.parent;
	var siteView = session.siteLayout.siteView;
	siteView.TopRight.visible(false);
	//siteView.TopCenter.visible(false);
	siteView.TopCenter.top(-100);
	siteView.TopCenterLarge.visible(true);
	siteView.TopCenterLarge.openView(
		{
			file: area + '/cwareabar.cwlv.json',
			name: 'TopAreaBar' + session.siteLayout.areaMenuIndex,
			openedFrom: openFrom
		}, {});
	session.siteLayout.areaMenuIndex++;
	if (session.siteLayout.areaMenuIndex > 20) {
		session.siteLayout.areaMenuIndex = 0;
	}
	return true;
}
session.siteLayout.openUserMgmtMenus = function (openFrom) {
	//var siteView = openFrom.parent.parent;
	var siteView = session.siteLayout.siteView;

	//siteView.TopCenter.visible(true);
	siteView.TopCenter.top(0);
	siteView.TopCenter.openView(
		{
			file: 'sitelayout/TopCenterUserMgmt.cwlv.json',
			name: 'TopCenterUser',
			openedFrom: openFrom
		}, {});
	siteView.TopCenterLarge.visible(false);
	siteView.TopRight.visible(true);
	siteView.TopRight.openView(
		{
			file: 'sitelayout/toprightmenu.cwlv.json',
			name: 'TopRightMenu',
			openedFrom: openFrom
		}, {});
	if (siteView.TopRight.currentView !== undefined) {
		siteView.TopRight.currentView.Dashboard.visible(false);
		siteView.TopRight.currentView.AlarmOverview.visible(false);
	}
	//var isLoggedIn = session.user.accessValue>0;
	if (session.siteLayout.getScreenSizeLevel() >= 1) {
		//Close menu for smallScreens...
		session.siteLayout.hideMainMenu();
	}

	return true;
}
session.onAccessDenied = function (args) {
	//console.log("sessionEvents.js:  Access is denied");
	args.element.view.openpopupwindow(
		{
			file: "siteLayout/AccessDeniedDialogBox.cwav.json",
			name: "AccessDeniedDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			//element: args.element,
			//executeManeuver: args.executeManeuver
		}
		,
		{
		}

	);
}
session.onNumericDialogBox = function (args) {
	//var me = this;
	args.element.view.openpopupwindow(
		{
			file: "S00000001.cwav.json",
			name: "NumericDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			element: args.element,
			view: args.element.view
			//executeManeuver: args.executeManeuver
		}
		,
		{

			//Description: args.element.userDescription(),
			//InitValue: args.element.value()		
			//kalleArg : args.element
		}

	);
}
session.onTextDialogBox = function (args) {
	//console.log("sessionEvents.js: onTextDialogBox");
	//var me = this;
	args.element.view.openpopupwindow(
		{
			file: "S00000002.cwav.json",
			name: "TextDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			element: args.element,
			//executeManeuver: args.executeManeuver
		}
		,
		{
		}

	);
}

session.onTextSelectDialogBox = function (args) {
	//console.log("sessionEvents.js: onTextSelectDialogBox");
	//var me = this;
	args.element.view.openpopupwindow(
		{
			file: "S00000003.cwav.json",
			name: "TextSelectDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			element: args.element,
			//executeManeuver: args.executeManeuver
		}
		,
		{
		}

	);
}

session.onDateDialogBox = function (args) {
	//console.log("sessionEvents.js: onDateDialogBox");
	//var me = this;
	args.element.view.openpopupwindow(
		{
			file: "S00000004.cwav.json",
			name: "DateDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			element: args.element,
			//executeManeuver: args.executeManeuver
		}
		,
		{
		}

	);
}

session.onTimeDialogBox = function (args) {
	//console.log("sessionEvents.js: onDateDialogBox");
	//var me = this;
	args.element.view.openpopupwindow(
		{
			file: "S00000005.cwav.json",
			name: "TimeDialogBox_" + args.element.name(),
			title: args.element.title(),
			icon: args.element.icon(),
			transition: this.session.transitions.immediate,
			openedFrom: args.element,
			element: args.element,
			//executeManeuver: args.executeManeuver
		}
		,
		{
		}

	);
}


